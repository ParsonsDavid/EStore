package Strategy;

/**
 * Created by David on 16/04/2017.
 */
public interface Strategy {
    double doOperation(double price);
}
